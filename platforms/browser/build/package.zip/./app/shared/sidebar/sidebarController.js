ctrl.controller('sidebarController', function($scope, $stateParams) {
  
});