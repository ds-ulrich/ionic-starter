ctrl.controller('headerController', function($scope, $stateParams) {
  
});